
public interface StrategyGhost {

	void randomChangeDirection(Ghost ghost);

}
